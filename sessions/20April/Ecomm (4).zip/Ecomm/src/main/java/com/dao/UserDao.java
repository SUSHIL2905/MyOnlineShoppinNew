package com.dao;

import com.model.User;

public interface UserDao 
{
	
	public void insertUser(User user);

}
