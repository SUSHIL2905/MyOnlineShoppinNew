package com.daoImpl;

public class SupplierDaoImpl {

}
